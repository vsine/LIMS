<?php

    function home(){
    $html=<<<EOT
EOT;


    return $html;
    }